library(testthat)
library(gscounts)

test_check("gscounts")
