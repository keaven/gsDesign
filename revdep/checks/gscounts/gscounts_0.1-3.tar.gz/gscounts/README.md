[![Travis Build Status](https://travis-ci.org/tobiasmuetze/gscounts.svg?branch=master)](https://travis-ci.org/tobiasmuetze/gscounts)
[![CRAN\_Status\_Badge](http://www.r-pkg.org/badges/version/gscounts)](https://cran.r-project.org/package=gscounts)
[![downloads](http://cranlogs.r-pkg.org/badges/grand-total/gscounts)](https://cranlogs.r-pkg.org/badges/grand-total/gscounts)
[![downloads](http://cranlogs.r-pkg.org/badges/gscounts)](https://cranlogs.r-pkg.org/badges/gscounts)

Installation
------------

``` r
# CRAN version 
install.packages("gscounts")

# Development version from GitHub
# install.packages("devtools")
devtools::install_github("tobiasmuetze/gscounts")
```
