# Test: upper bound is - O'Brien-Fleming

    [1] "O'Brien-Fleming boundary"

# Test: upper bound is - Pocock

    [1] "Pocock boundary"

# Test: upper bound is - WT

    [1] "Wang-Tsiatis boundary with Delta = 0.25"

# Test: Truncated object 

    [1] "Hwang-Shih-DeCani spending function compressed to 0.2, 0.8  with gamma = 1"

# Test: Trimmed object

    [1] "Hwang-Shih-DeCani spending function trimmed at 0.2, 0.8  with gamma = 1"

# Test: for Gapped object

    [1] "Hwang-Shih-DeCani spending function no spending in 0.2, 0.8  with gamma = 1"

