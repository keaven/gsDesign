# Test: object of class gsDesign - plot for y

                  Lower bounds   Upper bounds
      Analysis N    Z   Nominal p  Z   Nominal p
             1  1 -0.24    0.4057 3.01    0.0013
             2  1  0.94    0.8267 2.55    0.0054
             3  2  2.00    0.9772 2.00    0.0228
    
    Boundary crossing probabilities and expected sample size assume
    any cross stops the trial
    
    Upper boundary
              Analysis
       Theta      1      2      3  Total E{N}
      0.0000 0.0013 0.0049 0.0171 0.0233  0.6
      0.8104 0.0058 0.0279 0.0872 0.1209  0.8
      1.6208 0.0205 0.1038 0.2393 0.3636  0.9
      2.4311 0.0595 0.2579 0.3636 0.6810  0.9
      3.2415 0.1412 0.4403 0.3185 0.9000  0.8
      4.0519 0.2773 0.5353 0.1684 0.9810  0.7
      4.8623 0.4574 0.4844 0.0559 0.9976  0.6
      5.6727 0.6469 0.3410 0.0119 0.9998  0.5
      6.4830 0.8053 0.1930 0.0016 1.0000  0.4
    
    Lower boundary
              Analysis
       Theta      1      2      3  Total
      0.0000 0.4057 0.4290 0.1420 0.9767
      0.8104 0.2349 0.3812 0.2630 0.8791
      1.6208 0.1138 0.2385 0.2841 0.6364
      2.4311 0.0455 0.1017 0.1718 0.3190
      3.2415 0.0148 0.0289 0.0563 0.1000
      4.0519 0.0039 0.0054 0.0097 0.0190
      4.8623 0.0008 0.0006 0.0009 0.0024
      5.6727 0.0001 0.0001 0.0000 0.0002
      6.4830 0.0000 0.0000 0.0000 0.0000

# Test: object of class gsDesign  - plot for z

                  Lower bounds   Upper bounds
      Analysis N    Z   Nominal p  Z   Nominal p
             1  1 -0.24    0.4057 3.01    0.0013
             2  1  0.94    0.8267 2.55    0.0054
             3  2  2.00    0.9772 2.00    0.0228
    
    Boundary crossing probabilities and expected sample size assume
    any cross stops the trial
    
    Upper boundary
              Analysis
       Theta      1      2      3  Total E{N}
      0.0000 0.0013 0.0049 0.0171 0.0233  0.6
      0.8104 0.0058 0.0279 0.0872 0.1209  0.8
      1.6208 0.0205 0.1038 0.2393 0.3636  0.9
      2.4311 0.0595 0.2579 0.3636 0.6810  0.9
      3.2415 0.1412 0.4403 0.3185 0.9000  0.8
      4.0519 0.2773 0.5353 0.1684 0.9810  0.7
      4.8623 0.4574 0.4844 0.0559 0.9976  0.6
      5.6727 0.6469 0.3410 0.0119 0.9998  0.5
      6.4830 0.8053 0.1930 0.0016 1.0000  0.4
    
    Lower boundary
              Analysis
       Theta      1      2      3  Total
      0.0000 0.4057 0.4290 0.1420 0.9767
      0.8104 0.2349 0.3812 0.2630 0.8791
      1.6208 0.1138 0.2385 0.2841 0.6364
      2.4311 0.0455 0.1017 0.1718 0.3190
      3.2415 0.0148 0.0289 0.0563 0.1000
      4.0519 0.0039 0.0054 0.0097 0.0190
      4.8623 0.0008 0.0006 0.0009 0.0024
      5.6727 0.0001 0.0001 0.0000 0.0002
      6.4830 0.0000 0.0000 0.0000 0.0000

# Test: object of class gsBinomialExact

                  Bounds
      Analysis   N   a   b
             1  50   3  20
             2 100   7  30
    
    Boundary crossing probabilities and expected sample size assume
    any cross stops the trial
    
    Upper boundary
              Analysis
      Theta     1      2  Total E{N}
        0.1 0e+00 0.0000 0.0000 87.5
        0.2 9e-04 0.0107 0.0116 99.7
    
    Lower boundary
              Analysis
      Theta      1      2  Total
        0.1 0.2503 0.0717 0.3220
        0.2 0.0057 0.0001 0.0058

