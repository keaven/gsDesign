library(testthat)
library(gsDesign)

test_check("gsDesign")
