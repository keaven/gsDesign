#' @keywords internal
#' @aliases gsDesign-package
"_PACKAGE"
NULL
