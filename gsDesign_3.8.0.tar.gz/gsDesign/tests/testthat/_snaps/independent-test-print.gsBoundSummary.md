# Test print.gsBoundSummary

                   Analysis            Value Efficacy Futility
                  IA 1: 20%                Z   3.2527  -0.9016
     N/Fixed design N: 0.22      p (1-sided)   0.0006   0.8164
                                ~RR at bound   8.4830   0.5529
                            P(Cross) if RR=0   0.0006   0.1836
                            P(Cross) if RR=1   0.0417   0.0077
                  IA 2: 40%                Z   2.9860  -0.0367
     N/Fixed design N: 0.44      p (1-sided)   0.0014   0.5147
                                ~RR at bound   4.0065   0.9831
                            P(Cross) if RR=0   0.0018   0.5037
                            P(Cross) if RR=1   0.2096   0.0192
                  IA 3: 60%                Z   2.6917   0.6945
     N/Fixed design N: 0.66      p (1-sided)   0.0036   0.2437
                                ~RR at bound   2.7774   1.3016
                            P(Cross) if RR=0   0.0047   0.7737
                            P(Cross) if RR=1   0.4902   0.0363
                  IA 4: 80%                Z   2.3737   1.3603
     N/Fixed design N: 0.88      p (1-sided)   0.0088   0.0869
                                ~RR at bound   2.1818   1.5638
                            P(Cross) if RR=0   0.0109   0.9215
                            P(Cross) if RR=1   0.7556   0.0619
                      Final                Z   2.0253   2.0253
      N/Fixed design N: 1.1      p (1-sided)   0.0214   0.0214
                                ~RR at bound   1.8137   1.8137
                            P(Cross) if RR=0   0.0226   0.9774
                            P(Cross) if RR=1   0.9000   0.1000

