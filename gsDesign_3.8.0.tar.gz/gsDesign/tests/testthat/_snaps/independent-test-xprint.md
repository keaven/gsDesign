# test: Checking LaTeX output for gsDesign

    \begin{table}[ht]
    \centering
    \begin{tabular}{llrr}
      \hline
    Analysis & Value & Efficacy & Futility \\ 
      \hline
    IA 1: 50\% & Z & 2.75 & 0.41 \\ 
      N: 166 & p (1-sided) & 0.00 & 0.34 \\ 
       & \~{}OR at bound & 0.35 & 0.86 \\ 
       & P(Cross) if OR=1 & 0.00 & 0.66 \\ 
       & P(Cross) if OR=0.41 & 0.34 & 0.03 \\ 
       \hline
    Final & Z & 1.98 & 1.98 \\ 
      N: 332 & p (1-sided) & 0.02 & 0.02 \\ 
       & \~{}OR at bound & 0.59 & 0.59 \\ 
       & P(Cross) if OR=1 & 0.02 & 0.98 \\ 
       & P(Cross) if OR=0.41 & 0.90 & 0.10 \\ 
       \hline
    \end{tabular}
    \end{table}

