# Test - name - O'Brien-Fleming

    O'Brien-Fleming boundary

# Test - name - 'Pocock'

    Pocock boundary

# Test - name - Wang-Tsiatis

    Wang-Tsiatis boundary with Delta = 0.25

# Test - Truncated

    Hwang-Shih-DeCani spending function compressed to 0.2, 0.8 with gamma = 1

# Test - Trimmed

    Hwang-Shih-DeCani spending function trimmed at 0.2, 0.8 with gamma = 1

# Test - spending function

    argument 4 (type 'list') cannot be handled by 'cat'

