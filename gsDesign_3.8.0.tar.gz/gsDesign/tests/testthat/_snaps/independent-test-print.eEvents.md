# Test: checking for control group 

    Study duration:              Tfinal=4
    Analysis time:                    T=4
    Accrual duration:                   2
    Min. end-of-study follow-up: minfup=0
    Expected events (total):            4.8763
    Expected events by stratum:       d= 0.9415 0.8993 0.7675 0.8544 0.7884 0.6253
    Expected sample size (total):       6
    Sample size by stratum:           n= 1 1 1 1 1 1
    Number of strata:                   6
    Accrual rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-2       0.5       0.5       0.5       0.5       0.5       0.5
    Event rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-4         1       0.8       0.5    0.6667    0.5333    0.3333
    Censoring rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-4         0         0         0         0         0         0
    Study duration:              Tfinal=4
    Analysis time:                    T=4
    Accrual duration:                   2
    Min. end-of-study follow-up: minfup=0
    Expected events (total):            4.8763
    Expected events by stratum:       d= 0.9415 0.8993 0.7675 0.8544 0.7884 0.6253
    Expected sample size (total):       6
    Sample size by stratum:           n= 1 1 1 1 1 1
    Number of strata:                   6
    Accrual rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-2       0.5       0.5       0.5       0.5       0.5       0.5
    Event rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-4         1       0.8       0.5    0.6667    0.5333    0.3333
    Censoring rates:
        Stratum 1 Stratum 2 Stratum 3 Stratum 4 Stratum 5 Stratum 6
    0-4         0         0         0         0         0         0

